Enums
=====

.. autoclass:: vk_api.enums.VkUserPermissions
    :members:
    :show-inheritance:
