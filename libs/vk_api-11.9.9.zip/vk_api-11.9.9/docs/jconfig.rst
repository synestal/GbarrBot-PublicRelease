Пакет jconfig
=============

BaseConfig
---------------------------

.. autoclass:: jconfig.base.BaseConfig
    :members:

Config (хранение в json файле)
------------------------------

.. autoclass:: jconfig.jconfig.Config
    :members:
    :show-inheritance:

MemoryConfig (хранение в памяти)
--------------------------------

.. autoclass:: jconfig.memory.MemoryConfig
    :members:
    :show-inheritance:
