Исключения
==========

.. automodule:: vk_api.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
