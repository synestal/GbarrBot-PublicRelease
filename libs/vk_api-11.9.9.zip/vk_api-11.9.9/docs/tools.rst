VkTools
=======

Модуль для выкачивания множества результатов

.. module:: vk_api.tools
.. autoclass:: VkTools
    :members: