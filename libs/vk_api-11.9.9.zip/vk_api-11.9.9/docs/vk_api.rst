VkApi (основной класс)
======================

.. module:: vk_api.vk_api

.. autoclass:: VkApi
    :members:

.. autoclass:: VkUserPermissions
    :show-inheritance:
    :members:
