VkFunction
==========

Модуль для работы с методом execute

.. module:: vk_api.execute
.. autoclass:: VkFunction
    :members:
    :special-members: __call__
