VkRequestsPool
==============

Модуль для объединения запросов в один запрос execute

.. module:: vk_api.requests_pool
.. autoclass:: VkRequestsPool
    :members:
.. autoclass:: RequestResult
    :members:
.. autofunction:: vk_request_one_param_pool
