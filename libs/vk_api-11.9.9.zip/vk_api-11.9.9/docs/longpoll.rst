Модуль `longpoll` (VkLongPoll)
==============================

Модуль для работы с User Long Poll API

.. module:: vk_api.longpoll
.. autoclass:: VkLongPoll
    :members:
.. autoclass:: Event
    :members:
.. autoclass:: VkLongpollMode
    :members:
.. autoclass:: VkEventType
    :members:
.. autoclass:: VkPlatform
    :members:
.. autoclass:: VkOfflineType
    :members:
.. autoclass:: VkMessageFlag
    :members:
.. autoclass:: VkPeerFlag
    :members:
