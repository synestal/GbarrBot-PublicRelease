VkUpload
========

Модуль для загрузки медиафайлов в VK

.. module:: vk_api.upload
.. autoclass:: VkUpload
    :members: