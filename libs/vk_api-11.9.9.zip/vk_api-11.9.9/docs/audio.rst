VkAudio
=======

Модуль для работы с аудио

.. module:: vk_api.audio
.. autoclass:: VkAudio
    :members:
