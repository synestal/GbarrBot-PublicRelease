Модуль `bot_longpoll` (VkBotLongPoll)
=====================================

Модуль для работы с Bots Long Poll API

.. module:: vk_api.bot_longpoll
.. autoclass:: VkBotLongPoll
    :members:
.. autoclass:: VkBotEvent
    :members:
.. autoclass:: VkBotMessageEvent
    :show-inheritance:
    :members:
