VkKeyboard
==========

Модуль для удобного создания клавиатур для ботов

.. module:: vk_api.keyboard
.. autoclass:: VkKeyboard
    :members:
.. autoclass:: VkKeyboardColor
    :members:
.. autoclass:: VkKeyboardButton
    :members:
