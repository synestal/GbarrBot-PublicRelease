Бот работает через [longpoll](https://vk.com/dev/using_longpoll)
и использует [DuckDuckGo API](http://api.duckduckgo.com/) для получения ответа

![Пример работы бота](bot.png)
